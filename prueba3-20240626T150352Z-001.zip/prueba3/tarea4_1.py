import os
import datetime
import pyfiglet

data=datetime.datetime.now()
fecha_registrar=f"{data.day}/{data.month}/{data.year}"
def buscar_indice(id):
    i=0
    for e in productos:
        if e[0]==id:
            return i
        i+=1
    return -1
os.system("cls")

def inicio_programa():#Pyfiglet
    print(pyfiglet.figlet_format("centro de ventas de Frutos secos¡",font="speed",justify="center"))
    print("Integrantes: Nicolás Sandoval")
    os.system("pause")


def buscar(id):
    for a in productos:
        if a[0]==id:
            return a
    return -1


archivo = "productos.txt"
productos =   []
def leer_datos_archivo(archivo):
    lista_datos = []   
    with open("productos.txt", 'r') as file:
        for linea in file:
            linea = linea.strip()
            datos = linea.split(',')
            lista_datos.append(datos[0])
    return lista_datos

archivo2= "ventas.txt"
lista_ventas = []   
def leer_datos_archivo2(archivo2):#Vafiable que va dentro de los parentesis es una que se usara dentro de la misma funcion 
    with open("ventas.txt", 'r') as file:
        for linea in file:
            linea = linea.strip()
            datos = linea.split(',')
            lista_ventas.append([datos[0],datos[1],datos[2],int(datos[3]),int(datos[4])])
    return lista_ventas


def buscar(id):
    for lista in productos:
        if lista [0]== id:
            return lista
    else: return -1
def eliminar(id):
    lista_datos_actualizada = []
    existe=buscar(id)
    if existe != -1:
        with open(archivo, 'r') as file:
            for linea in file:
                linea = linea.strip()
                datos = linea.split(',')
                if datos[0] != id:
                    lista_datos_actualizada.append(linea)
        with open("ventas.txt", 'w') as file:
            for linea in lista_datos_actualizada:
                file.write(linea + '\n')    
    else:
        return -1

def imprimir_datos(lista_datos):
    for i in range (0,len(lista_datos),4):
        print(f"{lista_datos[i]}, {lista_datos[i+1]}, {lista_datos[i+2]}, {lista_datos[i+3]}, {lista_datos[i+4]}")

def agregar_datos(id, producto, tamaño, stock, precio):
    with open(archivo, 'a') as file:
        
        file.write(f"\n{id},{producto},{tamaño},{stock},{precio}")    

def modificar(id_a_modificar,nuevo_producto,nuevo_tamaño,nuevo_stock,nuevo_precio):
    lista_datos_actualizada = []
    id_encontrado = False
    with open(archivo, 'r') as file:
        for linea in file:
            linea = linea.strip()
            datos = linea.split(',')
            if datos[0] == id_a_modificar:
                datos[1] = nuevo_producto
                datos[2] = nuevo_tamaño
                datos[3] = int(nuevo_stock)
                datos[4] = int(nuevo_precio)
                id_encontrado = True
            lista_datos_actualizada.append(','.join(datos))
    if not id_encontrado:
        return -1
    with open(archivo, 'w') as file:
        for linea in lista_datos_actualizada:
            file.write(linea + '\n')
    return 1

def cargar_productos(archivo):
    
    with open("productos.txt", 'r') as file:
        for linea in file:
            linea=linea.strip()
            datos=linea.split(",")
            if datos[0] != "":
                productos.append([(datos[0]),datos[1],datos[2],int(datos[3]),int(datos[4])])
    return 1
def cargar_ventas(archivo2):
    with open("ventas.txt", 'r') as file:
        for linea in file:
            linea=linea.strip()
            datos=linea.split(",")
            if datos[0] != "":
                ventas.append([(datos[0]),datos[1],datos[2],int(datos[3]),int(datos[4])])
    return 1
def actualizar_producto(lista_datos,archivo):
    ultima_linea=len(productos)
    with open("productos.txt", "w") as file:
        c=1
        for e in productos:
            if c!=ultima_linea:
                file.write(f"{e[0]},{e[1]},{e[2]},{e[3]},{e[4]}\n")
            else:
                file.write(f"{e[0]},{e[1]},{e[2]},{e[3]},{e[4]}")
            c+=1
    return 1
def actualizar_ventas(lista_ventas,archivo2):
    ultima_linea=len(ventas)
    with open("ventas.txt", "w") as file:
        c=1
        for e in ventas:
            if c!=ultima_linea:
                file.write(f"{e[0]},{e[1]},{e[2]},{e[3]},{e[4]}\n")
            else:
                file.write(f"{e[0]},{e[1]},{e[2]},{e[3]},{e[4]}")
            c+=1
    return 1

def validar_fecha(fecha):
    """Valida si una fecha está en el formato dd-mm-yyyy y es correcta."""
    if len(fecha) != 10:
        return -1
    try:
        dia, mes, anio = map(int, fecha.split('-'))
        datetime(anio, mes, dia)  # Intentar crear un objeto datetime para validar la fecha
    except ValueError:
        return -1
    if anio <= 2000:
        return -1
    if mes < 1 or mes > 12:
        return -1
    if mes == 2:
        if es_bisiesto(anio):
            if dia < 1 or dia > 29:
                return -1
        else:
            if dia < 1 or dia > 28:
                return -1
    else:
        dias_en_mes = [31, 29 if es_bisiesto(anio) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        if dia < 1 or dia > dias_en_mes[mes - 1]:
            return -1

    return 1

def es_bisiesto(anio):
    """Determina si un año es bisiesto."""
    return anio % 4 == 0 and (anio % 100 != 0 or anio % 400 == 0)

def convertir_a_fecha(fecha_str):
    """Convierte una cadena de fecha en formato dd-mm-yyyy a un objeto datetime."""
    return datetime.strptime(fecha_str, '%d-%m-%Y')

def es_bisiesto(anio):
    """Determina si un año es bisiesto."""
    return anio % 4 == 0 and (anio % 100 != 0 or anio % 400 == 0)

def validar_fecha(fecha):
    """Valida si una fecha está en el formato dd-mm-yyyy y es correcta."""
    # Comprobar longitud
    if len(fecha) != 10:
        return -1

    try:
        dia, mes, anio = map(int, fecha.split('-'))
    except ValueError:
        return -1
    
    if not (1 <= dia <= 31) or not (1 <= mes <= 12) or anio <= 2000:
        return -1
    if mes == 2:
        if es_bisiesto(anio):
            if dia > 29:
                return -1
    else:
        if dia > 28:
            return -1
    dias_en_mes = [31, 29 if es_bisiesto(anio) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    if dia > dias_en_mes[mes - 1]:
        return -1
    return 1

def imprimir_datos(lista_datos):
    for x in lista_datos:
        print (x[0]," ",x[1]," ",x[2]," ",x[3]," ",x[4])

def validar_confirmacion():
    """Valida que la entrada del usuario sea 's' o 'n'."""
    while True:
        respuesta = input().lower()
        if respuesta in ['s', 'n']:
            return respuesta
        else:
            print("Entrada no válida. Por favor, ingrese 's' para sí o 'n' para no.")

def input_ncompra():pass

def get_folio():
    lenventas=(len(ventas)-1)
    folio=(ventas[lenventas][0]+1)

def registrar_venta(venta):
    with open('ventas.txt', 'a') as file:
        file.write(f"Folio: {venta[0]}\n")
        file.write(f"Fecha: {venta[1]}\n")
        file.write(f"ID Producto: {venta[2]}\n")
        file.write(f"Cantidad: {venta[3]}\n")
        file.write(f"Total: ${venta[4]:.2f}\n")
        file.write("-" * 20 + "\n")
    
productos = [
]

ventas = [  
]

inicio_programa()
opcion = 0

while True:

    print(
        """
            SISTEMA DE VENTAS
        ------------------------------         Version 0039   
        1. Vender productos
        2. Reportes.
        3. Mantenedores
        4. Administracion
        5.salir
        
        """
    )
    opcion = int(input("Ingrese una opción entre 1-5: "))

    match opcion:
        case 1:
            while True:
                os.system("cls")
                total=0
                print("comprar producto")
                id=input("ingrese id")
                lista=buscar(id)
                if lista!=-1:
                    print("producto encontrado")
                    print(lista)
                    cantidad=int(input("ingrese la cantidad que desea comprar "))
                    if cantidad<=lista[3]:
                        total+=(lista[4]*cantidad)
                        print(f"total a pagar: ${total}")
                        print("¿desea confirmar la compra? (s/n)")
                        preguntacompra=validar_confirmacion()
                        if preguntacompra=="s":
                            folio=get_folio()
                            ventas.append([folio,fecha_registrar,id,cantidad,total])
                            print("su compra realizada con exito")
                            os.system("pause")
                            print("desea realizar otra compra (s/n)")
                            preguntacompra1=validar_confirmacion
                            if preguntacompra1=="s":
                                continue
                            elif preguntacompra1=="n":
                                break
                        elif preguntacompra=="n":
                            break
                        else: 
                            print("opcion invalida ")

        case 2:
            while True :
                    total_folio=0
                    os.system("cls")
                    print("""
                            Reportes
                    (-------------------------)
                        1. General de ventas (con total)
                        2. Ventas por fecha especifica (con total)
                        3. Venta por rango de fecha (con total)
                        4. Salir al menu principal 

                        """)
                    op=int(input("ingrese una opcion de 1-4"))
                    match op:
                        case 1:
                            os.system("cls")
                            print("general de ventas ")
                            for x in ventas: 
                                print (x)
                        case 2:
                            fecha_bus=input("Ingrese la fecha a buscar (dd/mm/yyyy): ")
                            for i in ventas:
                                if i[1]==fecha_bus:
                                    print(i)
                                    total_folio+=i[4]
                            if total_folio==0:
                                print("No hay ventas en esa fecha")
                            else:
                                print(f"Total de ventas en la fecha ingresada: ${total_folio}")
                        case 3:
                                fecha_ini=input("Ingrese la fecha inicial (dd/mm/yyyy): ")
                                fecha_fin=input("Ingrese la fecha final (dd/mm/yyyy): ")
                                for i in ventas:
                                    if i[1] >= fecha_ini and i[1] <= fecha_fin:
                                        print(i)
                                        total_folio+=i[4]
                                print(f"Total de ventas entre las fechas: {total_folio}")

                        case 4:
                            break
                    os.system("pause")
        case 3:
            os.system("cls")    
            op = 0
            while op <= 6:
                print(
                    """
                        MANTENEDOR DE PRODUCTOS
                    ---------------------------------
                    1. Agregar
                    2. Buscar
                    3. Eliminar
                    4. Modificar
                    5. Listar
                    6. Salir al menú principal 
                    
                    """
                )
                op = int(input("Ingrese una opciòn 1-6: "))
                match op:
                    case 1:
                        print("\n Agregar Producto\n")
                        print("Agregar datos a la Lista de Productos \n")
                        agregar_id = input("Ingrese el id :  ")
                        agregar_producto = input("Ingrese su Producto:  ")
                        agregar_tamaño = input("Ingrese el tamaño:")
                        agregar_stock=int(input("ingrese el stock:"))
                        agregar_precio=int(input("ingrese el precio:"))
                        agregar_datos(agregar_id,agregar_producto,agregar_tamaño,agregar_stock,agregar_precio)
                        print("productos agregados")
                    case 2:
                        id = input("Ingrese su id a buscar:  ")
                        lista = buscar(id)
                        if lista != -1:
                            print(lista)
                        else:
                            print("Error, Producto no existe")

                    case 3:
                        id = input("Ingrese un id a eliminar:  ")
                        lista = buscar(id)
                        if lista != -1:
                            print("Producto eliminado")
                            productos.remove(lista)
                        else:
                            print("Error, Producto no existe")
                    case 4:
                        print("\n Modificar\n")
                        id = input("Ingrese un id a buscar:  ")
                        lista = buscar(id)
                        indice=buscar_indice(id)
                        if lista != -1:
                            print("Producto  encontrado")
                            print(lista)
                            print("\n")
                            nuevo_producto = input("Ingrese el nuevo nombre: ")
                            nuevo_tamaño = input("Ingrese el nuevo tamaño: ")
                            nuevo_stock = int(input("ingrese su nuevo stock"))
                            nuevo_precio=int(input("ingrese su nuevo precio"))
                            productos[indice]=[id,nuevo_producto,nuevo_tamaño,nuevo_stock,nuevo_precio]
                            print("\n Listo! datos modificados")
                        else:
                            print("Error, producto no existe")

                    case 5:
                        os.system("cls")
                        print("Listar productos")
                        print(productos)
                os.system("pause")
                if op == 6:
                    break 
        
        
        case 4:
            while True:
                op=0
                os.system("cls")
                print("""
                #administracion 
        ----------------------------
                1. Cargar Datos
                2. Respaldar datos
                3. salir
                
                
                
                """)
                try: op=int(input("Ingrese una opcion:"))
                except:
                    continue
                if op>=1 and op<=3:
                    os.system("cls")
                match op:
                    case 1:
                        print("Cargar datos\n")
                        cargar_productos(archivo)
                        cargar_ventas(archivo2)
                        print("Datos respaldados...")
                    
                    case 2:
                        print("Respaldar datos\n")
                        actualizar_producto(archivo,productos)
                        actualizar_ventas(archivo2,ventas)
                        print("Datos respaldados...")
                    
                    case 3:
                        print("Saliendo al menu principal...")
                        break
                
                    case _:
                        print("opcion fuera de rango...")
                        os.system("pause")
    if opcion == 5:
        break

print("Fin del menú")
